/**
 * 
 */
package pageObjects;


import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

public class Home_Page {

private static WebElement element = null;

public static WebElement txt_Search(WebDriver driver){

element = driver.findElement(By.name("searchTerm"));

return element;

}
public static WebElement txt_homeMsg(WebDriver driver){

element = driver.findElement(By.xpath("//h2[text()='RS Advantages']"));

return element;

}

public static WebElement btn_Search(WebDriver driver){

element = driver.findElement(By.id("btnSearch"));

return element;

}

public static WebElement lnk_LogOut(WebDriver driver){

element = driver.findElement(By.xpath("//a[text()= 'Log Out']"));

return element;

}

public static WebElement msg_name(WebDriver driver){

element = driver.findElement(By.name("Welcome meetu"));

return element;

}

}

