package pageObjects;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

public class SearchResults_Page {

private static WebElement element = null;

public static WebElement btn_Add(WebDriver driver){

element = driver.findElement(By.xpath("//div[text()='Add']"));

return element;

}

public static WebElement lnk_ViewBasket(WebDriver driver){

element = driver.findElement(By.xpath("//div[text()='View Basket']"));

return element;
}
public static WebElement lnk_RemoveFilters(WebDriver driver){

element = driver.findElement(By.linkText("Remove all"));

return element;
}
}

