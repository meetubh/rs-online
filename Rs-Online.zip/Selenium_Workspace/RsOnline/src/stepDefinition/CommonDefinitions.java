package stepDefinition;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.*;
import org.openqa.selenium.ie.*;
import pageObjects.Checkout_Page;
import pageObjects.Home_Page;
import pageObjects.Login_Page;
import pageObjects.SearchResults_Page;

import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;
import junit.framework.Assert;
import cucumber.api.java.en.And;

public class CommonDefinitions {

	WebDriver driver;
	
    @Given("^I opened the rs online application$")
	 public void open_rsonline_application() throws Throwable
	 {
      System.setProperty("webdriver.ie.driver", "src/IEDriverServer.exe");					
      driver = new InternetExplorerDriver();				
      driver.manage().window().maximize();	
      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	   
      driver.get("https://uk.rs-online.com/web/");
	 }
	 
	@And("^I am on Login page$")
	public void login_page() throws Throwable
	 {
	 Login_Page.lnk_Login(driver).click();
	 }
	@Then("^I login to the application using credentials$")
	public void enter_credentials() throws Throwable
	 {
		Login_Page.txtbx_UserName(driver).sendKeys("meetubh");
	Login_Page.txtbx_Password(driver).sendKeys("Happy@02");
		
		Login_Page.btn_LogIn(driver).click();
	 }
	@And("^I verify welcome page$")
	public void welcome_page(String Welcome) throws Throwable
	 {
		
	 String msg = driver.findElement(By.id("js-welcome")).getText();
	 
	 Assert.assertEquals(msg, Welcome);
	 }
   @Given("^I am on Home page$")
	public void home_page() throws Throwable
	 {
	 Home_Page.txt_homeMsg(driver).isDisplayed();
	 }
	 @And("^I log out from the application$")
	public void logout() throws Throwable
	 {
	 Home_Page.lnk_LogOut(driver).click();
	 }
	
}
