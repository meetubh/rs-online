package pageObjects;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

public class Checkout_Page { 

private static WebElement element = null;

public static WebElement btn_ClearAllProducts(WebDriver driver){

element = driver.findElement(By.linkText("Clear all Products"));

return element;

}
public static WebElement btn_checkout(WebDriver driver){

element = driver.findElement(By.id("checkoutSecurelyAndPuchBtn"));

return element;

}
public static WebElement msg_NoProducts(WebDriver driver){

element = driver.findElement(By.xpath("//td[contains(text(),'You do not have any products in your basket')]"));

return element;

}

}	

